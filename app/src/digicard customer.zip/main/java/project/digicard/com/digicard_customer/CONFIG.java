package project.digicard.com.digicard_customer;

/**
 * Created by Sarvesh on 21-12-2016.
 */

public class CONFIG {


        public static String REGISTER_URL="https://digicard.000webhostapp.com/register.php";
        public static String LOGIN_URL="https://digicard.000webhostapp.com/loginandroid.php";
        public static String GET_USERINFO="https://digicard.000webhostapp.com/getting_buyer_info.php";
        public static  String GET_CARDS="https://digicard.000webhostapp.com/getting_subscribed_cards.php";
        public static String GET_BILL="https://digicard.000webhostapp.com/buyer_getting_bill.php";
        public static String PUT_PIN="https://digicard.000webhostapp.com/buyer_putting_pin.php";



        public static String sharedprefcustid ="id";
        public static String sharedprefcustemail="email";
        public static String sharedprefcustphone="phone";
        public static String sharedprefcustname="name";
        public static String sharedprfisloggedin="islogin";
        public static final String MyPREFERENCES = "digicardbuyer" ;





}
